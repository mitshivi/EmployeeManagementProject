package empProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MongoDBRestController {
	@Autowired
	EmployeeDetailRepository empDetailRepo;
	
	@RequestMapping(value="/Employee", method =RequestMethod.GET)
	public List<EmployeeDetail> getDummyUser(){
		return empDetailRepo.findAll();
	}
	
	@RequestMapping(value = "/submitEmployeeDetail", method = RequestMethod.POST)
	public List<EmployeeDetail> newEmpDetail(@RequestBody EmployeeDetail emp) {
//		if(empDetailRepo.save(emp) != null) {
//			System.out.println("yipee");
//		};
		empDetailRepo.save(emp);
		 return empDetailRepo.findAll();
	}
	
	@RequestMapping(value = "/deleteEmployeeDetail/{id}", method = RequestMethod.DELETE)
	public List<EmployeeDetail> deleteEmployee(@PathVariable String id){
		empDetailRepo.deleteById(id);
		return empDetailRepo.findAll();
	}
	
	@RequestMapping(value = "/updateEmployeeDetail", method = RequestMethod.POST)
	public List<EmployeeDetail> udateEmployee(@RequestBody EmployeeDetail emp){
		empDetailRepo.save(emp);
		return empDetailRepo.findAll();
	}
	
	
	
}
