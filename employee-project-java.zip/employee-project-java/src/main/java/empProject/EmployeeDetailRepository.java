package empProject;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface EmployeeDetailRepository extends MongoRepository<EmployeeDetail,String> {

}
