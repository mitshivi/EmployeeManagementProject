package empProject;
import org.springframework.data.annotation.Id;
public class EmployeeDetail {
	@Id
	private String id;
	private int empId;
	private String empName;
	@Override
	public String toString() {
		return "EmployeeDetail [id=" + id + ", empId=" + empId + ", empName=" + empName + ", empLocation=" + empLocation
				+ ", empDesignation=" + empDesignation + "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpLocation() {
		return empLocation;
	}
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	private String empLocation;
	private String empDesignation;
}
