import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EmployeeDetail } from '../models/employee-detail.model'
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  getEmployeeDetails(): Observable<EmployeeDetail[]> {
    return this.http.get<EmployeeDetail[]>('http://localhost:8080/Employee');
  }

  newEmployeeDetails(emp: EmployeeDetail): Observable<EmployeeDetail[]> {
    return this.http.post<EmployeeDetail[]>('http://localhost:8080/submitEmployeeDetail', emp);
  }

  deleteEmployeeDetails(empId: String): Observable<EmployeeDetail[]> {
    return this.http.delete<EmployeeDetail[]>('http://localhost:8080/deleteEmployeeDetail/' + empId);
  }

  updateEmployeeDetails(emp: EmployeeDetail): Observable<EmployeeDetail[]> {
    return this.http.post<EmployeeDetail[]>('http://localhost:8080/updateEmployeeDetail', emp);
  }
}
