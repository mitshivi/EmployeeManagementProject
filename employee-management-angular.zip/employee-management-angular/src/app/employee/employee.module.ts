import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeInfoComponent } from './employee-info/employee-info.component';
import { PanelModule } from 'primeng/panel';
import { DataViewModule } from 'primeng/dataview';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [EmployeeInfoComponent],
  imports: [
    CommonModule,
    PanelModule,
    DataViewModule,
    TableModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    EmployeeInfoComponent,
    PanelModule
  ]
})
export class EmployeeModule { }
