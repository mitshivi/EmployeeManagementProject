import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { EmployeeDetail } from '../models/employee-detail.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-employee-info',
  templateUrl: './employee-info.component.html',
  styleUrls: ['./employee-info.component.css']
})
export class EmployeeInfoComponent implements OnInit {

  constructor(private empService: EmployeeService) { }
  employees: EmployeeDetail[];
  UpdateEmployee: EmployeeDetail;
  display: boolean;
  submitted: boolean;
  displayUpdateForm: boolean;
  empUpdateId = '';
  public newEmployeeDetail = new EmployeeDetail({});
  empDetailForm: FormGroup;
  empupdatedetailform: FormGroup;
  employeeDetailCol = [
    { feild: 'empId', header: 'Employee Id' },
    { feild: 'empName', header: 'Name' },
    { feild: 'empLocation', header: 'Location' },
    { feild: 'empDesignation', header: 'Designation' },
    { feild:  'actionbtns', header: ''}
  ];
  ngOnInit() {
    // reactive form validation for New Employee Detail Submission
    this.empDetailForm = new FormGroup({
      empName: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empId: new FormControl('', {
        validators: [Validators.required],
        updateOn:'blur'
      }),
      empLocation: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empDesignation: new FormControl('', {
        validators: [Validators.required],
        updateOn:'blur'
      }),
      empGender: new FormControl('', {
        validators: [Validators.required]
      })
    });
    this.UpdateEmployee = new EmployeeDetail({});
    // Reactive Form Validation for Updating the Existing Employee Details

    this.empupdatedetailform = new FormGroup({
      empName: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empId: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empLocation: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empDesignation: new FormControl('', {
        validators: [Validators.required],
        updateOn: 'blur'
      }),
      empGender: new FormControl('', {
        validators: [Validators.required]
      })
    })
    this.empService.getEmployeeDetails().subscribe(data => {
      this.employees = data;
    });
  }

  //for updating the employee Details
  onUpdateClick(emp) {
    this.displayUpdateForm = true;
    this.UpdateEmployee = emp;
    this.empUpdateId = emp.id;
    console.log('employee details to be updated', this.UpdateEmployee);
  }


  // For deleting a particular entry from Employee DataBase
  onDeleteClick(value) {
    this.empService.deleteEmployeeDetails(value.id).subscribe(data => { this.employees = data; });
  }
  addNewEmp() {
    this.display = true;
    this.enableEmpDetailForm();
    this.empDetailForm.reset();
  }

  submitDetails(value) {
    this.submitted = true;
    this.enableEmpDetailForm();
    if (this.isFormValid()) {
      this.display = false;
      this.empService.newEmployeeDetails(value).subscribe(data => { this.employees = data; console.log(data) });
      this.empDetailForm.reset();
      this.disableEmpDetailForm();
      this.submitted = false;
    }
  }

  get f() {
    return this.empDetailForm.controls;
  }
  get updatef() {
    return this.empupdatedetailform.controls;
  }

  enableEmpDetailForm(): void {
    this.empDetailForm.controls.empName.enable();
    this.empDetailForm.controls.empLocation.enable();
    this.empDetailForm.controls.empDesignation.enable();
    this.empDetailForm.controls.empGender.enable();
  }
  disableEmpDetailForm(): void {
    this.empDetailForm.controls.empName.disable();
    this.empDetailForm.controls.empLocation.disable();
    this.empDetailForm.controls.empDesignation.disable();
    this.empDetailForm.controls.empGender.disable();
  }
  resetForm(): void {
    this.empDetailForm.reset();
    this.newEmployeeDetail.empName = '';
    this.newEmployeeDetail.empLocation = '';
    this.newEmployeeDetail.empDesignation = '';
    this.newEmployeeDetail.empGender = '';
    this.submitted = false;
  }
  isFormValid() {
    return (this.empDetailForm.controls.empName.status === 'VALID' &&
      this.empDetailForm.controls.empLocation.status === 'VALID' &&
      this.empDetailForm.controls.empDesignation.status === 'VALID' &&
      this.empDetailForm.controls.empGender.status === 'VALID')
  }
  submitForUpdate(value) {
    console.log('valueeeee', value);
    this.submitted = true;
    this.UpdateEmployee = value;
    this.UpdateEmployee.id = this.empUpdateId;
    console.log('details after updation', value);
    if (this.isUpdateFormValid()) {
      this.displayUpdateForm = false;
      this.empService.updateEmployeeDetails(this.UpdateEmployee).subscribe(data => { this.employees=data });
      this.submitted = false;
    }
  }
  isUpdateFormValid() {
    return (this.empupdatedetailform.controls.empName.status === 'VALID' &&
      this.empupdatedetailform.controls.empLocation.status === 'VALID' &&
      this.empupdatedetailform.controls.empDesignation.status === 'VALID' &&
      this.empupdatedetailform.controls.empGender.status === 'VALID')
  }
}
