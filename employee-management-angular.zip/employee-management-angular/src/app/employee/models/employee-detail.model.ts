export class EmployeeDetail {
  public id: string;
  public empId: number;
  public empName: string;
  public empLocation: string;
  public empDesignation: string;
  public empGender: string;

  constructor(employeeDetail?: any) {
    this.id = employeeDetail.id || '';
    this.empId = employeeDetail.empId || '';
    this.empName = employeeDetail.empName || '';
    this.empLocation = employeeDetail.empLocation || '';
    this.empDesignation = employeeDetail.empDesignation || '';
    this.empGender = employeeDetail.empGender || '';
  }
}
